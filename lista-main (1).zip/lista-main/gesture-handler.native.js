// Only import react-native-gesture-handler on native platforms
import 'react-native-gesture-handler';