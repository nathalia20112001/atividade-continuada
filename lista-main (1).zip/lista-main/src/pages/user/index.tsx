import React,{ useState } from "react";
import { style } from "./styles";
import {Text, View,Image, Alert} from 'react-native'
export default function User (){
    return(
        <View style={style.container}>
            <Text>Users</Text>
        </View>
    )
}