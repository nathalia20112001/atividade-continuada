
export const themas = {
    Colors :{
        primary:'#878af6',
        secondary:'#ffffff',
        lightGray:'#d7d8d7',
        gray:'gray',
        bgScreen:'#f1f7fa',
        red:'#FF494C',
        blueLigth:'#87CEF6'
    }
}